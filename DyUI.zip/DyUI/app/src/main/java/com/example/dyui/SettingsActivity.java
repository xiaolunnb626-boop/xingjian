package com.example.dyui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.*;

public class SettingsActivity extends Activity {
    @SuppressLint("WorldReadableFiles")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp;
        try { sp = getSharedPreferences("settings", Context.MODE_WORLD_READABLE); }
        catch (SecurityException e) { sp = getSharedPreferences("settings", MODE_PRIVATE); }
        final SharedPreferences prefs = sp;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        Switch sw = new Switch(this);
        sw.setText("启用美化");
        sw.setChecked(prefs.getBoolean("enabled", true));
        root.addView(sw);

        TextView tip = new TextView(this);
        tip.setText("\n隐藏包含以下文字的控件（逗号分隔）：");
        root.addView(tip);

        EditText et = new EditText(this);
        et.setText(prefs.getString("hide_keywords", ""));
        root.addView(et, new ViewGroup.LayoutParams(-1, -2));

        Button save = new Button(this);
        save.setText("保存（重启抖音生效）");
        save.setOnClickListener(v -> {
            prefs.edit().putBoolean("enabled", sw.isChecked())
                .putString("hide_keywords", et.getText().toString()).apply();
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);
        setContentView(root);
    }
}
