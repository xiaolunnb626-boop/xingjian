package com.example.dyui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.SystemClock;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.RenderEffect;
import android.graphics.RenderNode;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import dalvik.system.DexClassLoader;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage, IXposedHookZygoteInit {
    static final String HOST = "com.ss.android.ugc.aweme";
    static final String TAG = "dyui_entry";
    // 用设置页里两个固定文字定位列表容器，不依赖混淆后的类名/ID
    static final String ANCHOR1 = "账号与安全";
    static final String ANCHOR2 = "通用设置";
    static boolean toasted = false;
    static boolean posUnsupported = false;
    static boolean glassEnabled = false;
    static boolean menuGlassEnabled = false;
    static long lastMenuScan = 0;
    static final ArrayList<WeakReference<View>> menuGlassTargets = new ArrayList<>();
    static final ArrayList<MenuGlassRecord> menuGlassRecords = new ArrayList<>();
    static class MenuGlassRecord {
        WeakReference<ViewGroup> parent;
        WeakReference<ViewGroup> wrapper;
        WeakReference<View> original;
        ViewGroup.LayoutParams params;
        int index;
        MenuGlassRecord(ViewGroup p, ViewGroup w, View o, ViewGroup.LayoutParams lp, int i) {
            parent = new WeakReference<>(p);
            wrapper = new WeakReference<>(w);
            original = new WeakReference<>(o);
            params = lp;
            index = i;
        }
    }
    static boolean failToasted = false;
    static long lastCheck = 0, lastClick = 0;
    static ViewTreeObserver.OnPreDrawListener glassListener;
    static WeakReference<Activity> glassActRef;
    static WeakReference<View> glassDecorRef, hostRef, overlayRef, btnRef;
    static boolean hasBtn = false;
    static WeakReference<ViewGroup> navRef;
    static ArrayList<WeakReference<View>> realTabs;
    static int prevSel = 0, lastTheme = -1;
    static boolean syncing = false;
    static boolean fingerDown = false;
    static long lastUp = 0;
    static int stuckCount = 0;
    static Method mGetAnim, mPressProg, mRelease, mReleaseNow;

    static boolean touchSeen = false;           // 已经观察到过触摸事件（才启用“卡住松开”兜底）
    static final float SCALE = 0.82f;           // 整体缩小比例：通过缩小 density 实现，不做视图缩放
    static Method mSetSel, mSetContent, mSetContainer;
    static String modulePath, libError;
    static ClassLoader libCl;
    static final String OVERLAY_TAG = "dyui_overlay";
    static final String LG = "com.liquidglass.java.miba.";
    static WeakReference<Activity> mainRef;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!HOST.equals(lpp.packageName)) return;
        // 全局记录手指是否按下；按在玻璃导航栏/按钮上时，禁止抖音的父布局拦截后续触摸
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "dispatchTouchEvent", MotionEvent.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        int act = ((MotionEvent) param.args[0]).getActionMasked();
                        if (act == MotionEvent.ACTION_DOWN) { fingerDown = true; touchSeen = true; }
                        else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                            fingerDown = false;
                            lastUp = SystemClock.uptimeMillis();
                        }
                    } catch (Throwable ignored) { }
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        MotionEvent ev = (MotionEvent) param.args[0];
                        if (ev.getActionMasked() != MotionEvent.ACTION_DOWN) return;
                        View[] vs = {ref(overlayRef), ref(btnRef)};
                        for (View v : vs) {
                            if (v == null || v.getVisibility() != View.VISIBLE || v.getParent() == null) continue;
                            int[] loc = new int[2];
                            v.getLocationOnScreen(loc);
                            float x = ev.getRawX(), y = ev.getRawY();
                            if (x >= loc[0] && x <= loc[0] + v.getWidth() && y >= loc[1] && y <= loc[1] + v.getHeight())
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) { XposedBridge.log(t); }

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    final Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow().getDecorView();
                    if (a.getClass().getName().contains("MainActivity")) {
                        mainRef = new WeakReference<>(a);
                        decor.postDelayed(() -> applyGlass(a, decor), 800);
                    } else {
                        tryInject(a, decor, 0);
                    }
                    decor.postDelayed(() -> applyBeautify(a, decor), 600);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    // ---------- 注入设置页顶部入口 ----------

    static void tryInject(final Activity a, final View decor, final int n) {
        if (n > 8 || decor.findViewWithTag(TAG) != null) return;
        decor.postDelayed(() -> {
            try {
                if (decor.findViewWithTag(TAG) != null) return;
                View t1 = findText(decor, ANCHOR1), t2 = findText(decor, ANCHOR2);
                if (t1 == null || t2 == null) { tryInject(a, decor, n + 1); return; }
                if (!toasted) {
                    toasted = true;
                    Toast.makeText(a, "抖音美化：启动成功", Toast.LENGTH_LONG).show();
                }
                ViewGroup box = lca(t1, t2);
                if (box == null) { XposedBridge.log("DyUI: container not found"); return; }
                inject(a, box);
            } catch (Throwable t) { XposedBridge.log(t); }
        }, 300);
    }

    static void inject(Activity a, ViewGroup box) {
        XposedBridge.log("DyUI: container=" + box.getClass().getName());
        int h = dp(a, 74);
        if (box instanceof LinearLayout && ((LinearLayout) box).getOrientation() == LinearLayout.VERTICAL) {
            box.addView(buildEntry(a), 0, new LinearLayout.LayoutParams(-1, h));
        } else if (isRecycler(box) && box.getParent() instanceof ViewGroup) {
            overlay(a, box, h);
        } else {
            XposedBridge.log("DyUI: unsupported container " + box.getClass().getName());
        }
    }

    // RecyclerView：在其上方叠一个入口，并跟随列表滚动
    static void overlay(Activity a, final ViewGroup rv, final int h) {
        ViewGroup parent = (ViewGroup) rv.getParent();
        final View e = buildEntry(a);
        if (parent instanceof LinearLayout && ((LinearLayout) parent).getOrientation() == LinearLayout.VERTICAL) {
            parent.addView(e, parent.indexOfChild(rv), new LinearLayout.LayoutParams(-1, h));
            return;
        }
        rv.setPadding(rv.getPaddingLeft(), rv.getPaddingTop() + h, rv.getPaddingRight(), rv.getPaddingBottom());
        rv.setClipToPadding(false);
        parent.addView(e, new ViewGroup.LayoutParams(-1, h));
        rv.getViewTreeObserver().addOnPreDrawListener(() -> {
            try { sync(rv, e, h); } catch (Throwable ignored) { }
            return true;
        });
    }

    static void sync(ViewGroup rv, View e, int h) {
        float base = rv.getTop();
        if (!posUnsupported) {
            try {
                for (int i = 0; i < rv.getChildCount(); i++) {
                    View c = rv.getChildAt(i);
                    Object pos = XposedHelpers.callMethod(rv, "getChildAdapterPosition", c);
                    if (pos instanceof Integer && (Integer) pos == 0) {
                        e.setVisibility(View.VISIBLE);
                        e.setTranslationY(base + c.getTop() - h);
                        return;
                    }
                }
                e.setVisibility(View.INVISIBLE);
                return;
            } catch (Throwable t) { posUnsupported = true; }
        }
        // 兜底：取不到位置时，只在列表顶部显示
        e.setVisibility(rv.canScrollVertically(-1) ? View.INVISIBLE : View.VISIBLE);
        e.setTranslationY(base);
    }

    static boolean isRecycler(View v) {
        for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass())
            if (c.getName().contains("RecyclerView")) return true;
        return false;
    }

    static View findText(View v, String t) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) return v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findText(g.getChildAt(i), t);
                if (r != null) return r;
            }
        }
        return null;
    }

    // 两个文字的最近公共父容器 = 整个设置列表
    static ViewGroup lca(View a, View b) {
        Set<ViewParent> s = new HashSet<>();
        for (ViewParent p = a.getParent(); p != null; p = p.getParent()) s.add(p);
        for (ViewParent p = b.getParent(); p != null; p = p.getParent())
            if (p instanceof ViewGroup && s.contains(p)) return (ViewGroup) p;
        return null;
    }

    // ---------- 入口卡片（仿设置页的圆角白卡片） ----------

    static View buildEntry(final Activity a) {
        boolean night = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        FrameLayout wrap = new FrameLayout(a);
        wrap.setTag(TAG);
        wrap.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(night ? Color.parseColor("#252525") : Color.WHITE);
        bg.setCornerRadius(dp(a, 12));
        card.setBackground(bg);

        TextView t = new TextView(a);
        t.setText("抖音美化");
        t.setTextSize(16);
        t.setTextColor(night ? Color.parseColor("#E8E8E8") : Color.parseColor("#161823"));
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        wrap.addView(card, new FrameLayout.LayoutParams(-1, -1));
        wrap.setOnClickListener(v -> showMain(a));
        return wrap;
    }

    // ---------- 功能列表页（全屏页面，仿设置页风格） ----------

    static boolean isNight(Activity a) {
        return (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static TextView tv(Activity a, String s, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static Dialog page(final Activity a, String title, View... sections) {
        boolean n = isNight(a);
        final Dialog d = new Dialog(a, n ? android.R.style.Theme_Material_NoActionBar
                : android.R.style.Theme_Material_Light_NoActionBar);
        int bg = n ? 0xFF121212 : 0xFFF4F4F4;
        int fg = n ? 0xFFE8E8E8 : 0xFF161823;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        FrameLayout bar = new FrameLayout(a);
        TextView tt = tv(a, title, 17, fg);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        bar.addView(tt, new FrameLayout.LayoutParams(-1, -1));
        TextView back = tv(a, "‹", 30, fg);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> d.dismiss());
        bar.addView(back, new FrameLayout.LayoutParams(dp(a, 56), -1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(a, 52)));

        ScrollView sv = new ScrollView(a);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 24));
        for (View v : sections) list.addView(v);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(-1, -1);
            w.setStatusBarColor(bg);
            w.setNavigationBarColor(bg);
            w.getDecorView().setSystemUiVisibility(n ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        d.show();
        return d;
    }

    static LinearLayout card(Activity a) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(isNight(a) ? 0xFF252525 : 0xFFFFFFFF);
        g.setCornerRadius(dp(a, 12));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(a, 12);
        c.setLayoutParams(lp);
        return c;
    }

    static void addRow(Activity a, LinearLayout card, String text, View trailing, final Runnable click) {
        boolean n = isNight(a);
        if (card.getChildCount() > 0) {
            View dv = new View(a);
            dv.setBackgroundColor(n ? 0x22FFFFFF : 0x14000000);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.leftMargin = dp(a, 16);
            card.addView(dv, dl);
        }
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        r.addView(tv(a, text, 16, n ? 0xFFE8E8E8 : 0xFF161823), new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) r.addView(trailing);
        if (click != null) r.setOnClickListener(v -> click.run());
        card.addView(r, new LinearLayout.LayoutParams(-1, dp(a, 56)));
    }

    static View arrow(Activity a) { return tv(a, "›", 22, 0xFF9A9A9A); }

    static void showMain(final Activity a) {
        LinearLayout c = card(a);
        addRow(a, c, "美化功能", arrow(a), () -> showBeautify(a));
        LinearLayout c2 = card(a);
        addRow(a, c2, "复制诊断信息（底部导航结构）", null, () -> copyDiag(a));
        page(a, "抖音美化", c, c2);
    }

    static void showBeautify(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout c = card(a);
        final Switch sw = new Switch(a);
        sw.setChecked(sp.getBoolean("liquid_nav", false));
        sw.setOnCheckedChangeListener((b, on) -> {
            sp.edit().putBoolean("liquid_nav", on).apply();
            Toast.makeText(a, on ? "已开启，回到首页后生效" : "已关闭", Toast.LENGTH_SHORT).show();
        });
        addRow(a, c, "1. 底部导航：液态玻璃", sw, () -> sw.toggle());
        final Switch menuSw = new Switch(a);
        menuSw.setChecked(sp.getBoolean("liquid_menu", false));
        menuSw.setOnCheckedChangeListener((b, on) -> {
            sp.edit().putBoolean("liquid_menu", on).apply();
            Toast.makeText(a, on ? "个人菜单液态玻璃已开启，返回抖音主页生效" : "个人菜单液态玻璃已关闭", Toast.LENGTH_SHORT).show();
        });
        addRow(a, c, "2. 个人菜单：动态液态玻璃", menuSw, () -> menuSw.toggle());
        addRow(a, c, "3. 隐藏指定文字的控件", arrow(a), () -> showHide(a));
        page(a, "美化功能", c);
    }

    static void showHide(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), 0);

        final Switch sw = new Switch(a);
        sw.setText("启用");
        sw.setChecked(sp.getBoolean("enabled", true));
        box.addView(sw);

        TextView tip = new TextView(a);
        tip.setText("\n隐藏包含以下文字的控件（逗号分隔）：");
        box.addView(tip);

        final EditText et = new EditText(a);
        et.setText(sp.getString("hide_keywords", ""));
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(a)
                .setTitle("隐藏指定文字的控件")
                .setView(box)
                .setPositiveButton("保存", (d, w) -> {
                    sp.edit().putBoolean("enabled", sw.isChecked())
                            .putString("hide_keywords", et.getText().toString()).apply();
                    Toast.makeText(a, "已保存，重新进入页面后生效", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------- 底部导航：定位 + 诊断（液态玻璃的前置步骤） ----------

    // ---------- 液态玻璃底栏：加载 LiquidGlass.dex，在原底栏上叠一个 LiquidBottomTabs ----------

    @Override
    public void initZygote(StartupParam startupParam) { modulePath = startupParam.modulePath; }

    static <T> T ref(WeakReference<T> r) { return r == null ? null : r.get(); }

    // 缩小 density 的 Context：组件内部所有 dp/sp 都按比例变小，布局本身就是小的（不用缩放视图，避免位置计算出错）
    static Context scaledCtx(Activity a, float f) {
        Configuration cfg = new Configuration(a.getResources().getConfiguration());
        cfg.densityDpi = Math.round(cfg.densityDpi * f);
        final Resources res = a.createConfigurationContext(cfg).getResources();
        return new ContextWrapper(a) {
            @Override
            public Resources getResources() { return res; }
        };
    }

    static void toastOnce(Activity a, String msg) {
        if (failToasted) return;
        failToasted = true;
        Toast.makeText(a, msg, Toast.LENGTH_LONG).show();
    }

    // 把模块里的 dex 复制到抖音的 code_cache（只读），再用 DexClassLoader 加载
    static ClassLoader loadLib(Activity a) {
        if (libCl != null) return libCl;
        try {
            File dir = new File(a.getCodeCacheDir(), "dyui");
            dir.mkdirs();
            File f = new File(dir, "LiquidGlass.dex");
            ZipFile zf = new ZipFile(modulePath);
            try {
                ZipEntry ze = zf.getEntry("assets/LiquidGlass.dex");
                if (ze == null) throw new IllegalStateException("module asset missing");
                if (!f.exists() || f.length() != ze.getSize()) {
                    f.setWritable(true);
                    f.delete();
                    InputStream in = zf.getInputStream(ze);
                    FileOutputStream out = new FileOutputStream(f);
                    try {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    } finally { out.close(); in.close(); }
                    f.setReadOnly();
                }
            } finally { zf.close(); }
            libCl = new DexClassLoader(f.getAbsolutePath(), null, null, a.getClassLoader());
        } catch (Throwable t) {
            libError = String.valueOf(t);
            XposedBridge.log(t);
        }
        return libCl;
    }

    static void applyGlass(Activity a, View decor) {
        try {
            SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
            glassEnabled = sp.getBoolean("liquid_nav", false);
            menuGlassEnabled = sp.getBoolean("liquid_menu", false);
            if (glassEnabled || menuGlassEnabled) {
                installNav(a, decor);
                if (!menuGlassEnabled) removeMenuGlass();
            } else removeNav();
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    static void installNav(Activity a, View decor) {
        glassActRef = new WeakReference<>(a);
        View oldDecor = ref(glassDecorRef);
        if (oldDecor != decor) {
            if (oldDecor != null && glassListener != null) {
                try { oldDecor.getViewTreeObserver().removeOnPreDrawListener(glassListener); }
                catch (Throwable ignored) { }
            }
            glassListener = () -> {
                try { tickNav(); } catch (Throwable t) { XposedBridge.log(t); }
                return true;
            };
            decor.getViewTreeObserver().addOnPreDrawListener(glassListener);
            glassDecorRef = new WeakReference<>(decor);
        }
        if (glassEnabled) ensureNav(a, decor); else removeNav0();
    }

    // 每帧：让叠加层跟随原底栏的显示/隐藏/位移；每 0.4 秒：检查是否需要重建、同步选中项和主题
    static void tickNav() {
        View host = ref(hostRef);
        if (host != null) {
            mirror(ref(overlayRef), host);
            mirror(ref(btnRef), host);
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastCheck < 400) return;
        lastCheck = now;
        unstick();
        Activity act = ref(glassActRef);
        View dec = ref(glassDecorRef);
        if (act != null && dec != null) {
            if (glassEnabled) ensureNav(act, dec);
            if (menuGlassEnabled && now - lastMenuScan > 650) {
                lastMenuScan = now;
                scanMenuCards(act, dec);
            }
        }
    }

    // 兜底：如果滑块一直卡在“按下放大”状态，手动让它松开
    static void unstick() {
        View ov = ref(overlayRef);
        if (!touchSeen || ov == null || mGetAnim == null || mPressProg == null || mRelease == null) return;
        try {
            Object an = mGetAnim.invoke(ov);
            float pp = ((Float) mPressProg.invoke(an)).floatValue();
            if (pp > 0.02f && !fingerDown && SystemClock.uptimeMillis() - lastUp > 1200) {
                stuckCount++;
                if (stuckCount == 1) mRelease.invoke(an);
                else if (stuckCount >= 3 && mReleaseNow != null) mReleaseNow.invoke(an);
            } else {
                stuckCount = 0;
            }
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    static void mirror(View ov, View host) {
        if (ov == null) return;
        ov.setTranslationY(host.getTranslationY());
        ov.setAlpha(host.getAlpha());
        ov.setVisibility(host.getVisibility());
    }

    // 可选的反射调用：方法不存在时只记日志，不影响主流程
    static void opt(Object o, String name, Class<?> type, Object arg) {
        try { o.getClass().getMethod(name, type).invoke(o, arg); }
        catch (Throwable t) { XposedBridge.log("DyUI opt " + name + ": " + t); }
    }

    static void optNo(Object o, String name) {
        try { o.getClass().getMethod(name).invoke(o); }
        catch (Throwable t) { XposedBridge.log("DyUI optNo " + name + ": " + t); }
    }

    static void ensureNav(Activity a, View decor) {
        View host = ref(hostRef), ov = ref(overlayRef), btn = ref(btnRef);
        ViewGroup nav = ref(navRef);
        if (host != null && ov != null && nav != null && host.isAttachedToWindow() && ov.getParent() != null
                && (!hasBtn || (btn != null && btn.getParent() != null))) {
            refreshNav(nav, host);
            return;
        }
        removeNav0();
        ViewGroup nav2 = findNav(decor);
        if (nav2 == null) return;
        View h = null;
        for (ViewParent p = nav2.getParent(); p instanceof View; p = p.getParent()) {
            if (p.getClass().getName().contains("MainBottomTabContainer")) { h = (View) p; break; }
        }
        if (h == null || !(h.getParent() instanceof FrameLayout)) {
            XposedBridge.log("DyUI: host/parent unsupported");
            return;
        }
        ClassLoader cl = loadLib(a);
        if (cl == null) { toastOnce(a, "液态玻璃库加载失败：" + libError); return; }

        try {
            // 中间的发布按钮(+)单独拿出来做成独立的液态玻璃按钮，其余 tab 放进胶囊导航栏
            ArrayList<WeakReference<View>> real = new ArrayList<>();
            ArrayList<String> labels = new ArrayList<>();
            View pubView = null;
            for (int i = 0; i < nav2.getChildCount(); i++) {
                View c = nav2.getChildAt(i);
                if (c.getVisibility() == View.GONE) continue;
                if (pubView == null && c.getClass().getName().contains("PublishButton")) { pubView = c; continue; }
                real.add(new WeakReference<>(c));
                labels.add(labelOf(c));
            }
            if (real.size() < 2) { XposedBridge.log("DyUI: too few tabs"); return; }

            Class<?> tabsC = cl.loadClass(LG + "LiquidBottomTabs");
            Class<?> tabC = cl.loadClass(LG + "LiquidBottomTab");
            Class<?> btnC = cl.loadClass(LG + "LiquidButton");
            Class<?> lisC = cl.loadClass(LG + "LiquidBottomTabs$OnTabSelectedListener");

            // 使用 LiquidGlass 自带的自动背景捕获，不再绑定 EmptyBackdrop。
            final Context sctx = scaledCtx(a, SCALE);
            Object tabs = tabsC.getConstructor(Context.class).newInstance(sctx);
            tabsC.getMethod("setAutoBackdropEnabled", boolean.class).invoke(tabs, true);
            opt(tabs, "setAutoBackdropContinuous", boolean.class, true);
            tabsC.getMethod("setAdaptiveContentColorEnabled", boolean.class).invoke(tabs, false);

            Method add = tabsC.getMethod("addTab", tabC);
            Method setText = tabC.getMethod("setText", CharSequence.class);
            for (String label : labels) {
                Object tab = tabC.getConstructor(Context.class).newInstance(sctx);
                setText.invoke(tab, label);
                opt(tab, "setTextSizeSp", float.class, 15f);
                add.invoke(tabs, tab);
            }
            mSetSel = tabsC.getMethod("setSelectedIndex", int.class, boolean.class);
            mSetContent = tabsC.getMethod("setContentColor", int.class);
            mSetContainer = tabsC.getMethod("setContainerColor", int.class);
            try {
                mGetAnim = tabsC.getMethod("getDampedDragAnimation");
                Class<?> animC = mGetAnim.getReturnType();
                mPressProg = animC.getMethod("getPressProgress");
                mRelease = animC.getMethod("release");
                mReleaseNow = animC.getMethod("releasePressNow");
            } catch (Throwable t) { XposedBridge.log(t); }

            Object lis = Proxy.newProxyInstance(cl, new Class<?>[]{lisC}, (pr, m, args) -> {
                if ("onTabSelected".equals(m.getName()) && args != null && args.length == 2) {
                    onSelected(((Integer) args[1]).intValue());
                }
                Class<?> rt = m.getReturnType();
                if (rt == boolean.class) return Boolean.FALSE;
                if (rt == int.class) return 0;
                return null;
            });
            tabsC.getMethod("setOnTabSelectedListener", lisC).invoke(tabs, lis);

            View btnView = null;
            if (pubView != null) {
                Object btn2 = btnC.getConstructor(Context.class).newInstance(sctx);
                btnC.getMethod("setAutoBackdropEnabled", boolean.class).invoke(btn2, true);
                opt(btn2, "setAutoBackdropContinuous", boolean.class, true);
                btnC.getMethod("setAdaptiveContentColorEnabled", boolean.class).invoke(btn2, false);
                btnC.getMethod("setText", CharSequence.class).invoke(btn2, "＋");
                opt(btn2, "setTextSizeSp", float.class, 24f);
                opt(btn2, "setCornerRadiusDp", float.class, 26f);
                publishRef = new WeakReference<>(pubView);
                btnC.getMethod("setOnClickAction", Runnable.class).invoke(btn2, (Runnable) () -> {
                    View pv = ref(publishRef);
                    if (pv != null) clickReal(pv);
                });
                btnView = (View) btn2;
                btnView.setTag(OVERLAY_TAG);
            }

            View view = (View) tabs;
            view.setTag(OVERLAY_TAG);
            FrameLayout parent = (FrameLayout) h.getParent();
            int oh = dp(a, 64 * SCALE), btnSize = dp(a, 52), side = dp(a, 22), gap = dp(a, 8);
            int bm = Math.max(0, parent.getHeight() - h.getBottom()) + dp(a, 16);   // 比原底栏再抬高 16dp
            int left = side;
            if (btnView != null) {
                FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(btnSize, btnSize, Gravity.BOTTOM | Gravity.LEFT);
                bl.setMargins(side, 0, 0, bm);
                parent.addView(btnView, bl);
                left = side + btnSize + gap;
            }
            int avail = parent.getWidth() - left - side;
            int w = avail > 0 ? avail : -1;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, oh, Gravity.BOTTOM | Gravity.LEFT);
            lp.setMargins(left, 0, 0, bm);
            parent.addView(view, lp);
            // 原底栏保留（继续负责真正的点击/状态），只是不再绘制
            h.setClipBounds(new Rect(-10000, -10000, -9999, -9999));

            realTabs = real;
            prevSel = 0;
            lastTheme = -1;
            hasBtn = btnView != null;
            hostRef = new WeakReference<>(h);
            overlayRef = new WeakReference<>(view);
            btnRef = btnView == null ? null : new WeakReference<>(btnView);
            navRef = new WeakReference<>(nav2);
            refreshNav(nav2, h);

            // 布局完成后重新同步一次：重建镜像行并把滑块对齐到当前选中的 tab（避免滑块和文字错位）
            int init = 0;
            for (int i = 0; i < real.size(); i++) {
                View c = real.get(i).get();
                if (c != null && isSel(c, 0)) { init = i; break; }
            }
            prevSel = init;
            final View fv = view;
            Runnable resync = () -> { optNo(fv, "refreshCaptureTabs"); setSel(prevSel, false); };
            view.post(resync);
            view.postDelayed(resync, 350);
        } catch (Throwable t) {
            XposedBridge.log(t);
            toastOnce(a, "液态玻璃创建失败：" + t);
            removeNav0();
        }
    }

    static WeakReference<View> publishRef;

    // 同步：抖音当前选中的 tab → 叠加层；抖音底栏主题（深/浅）→ 玻璃颜色
    static void refreshNav(ViewGroup nav, View host) {
        View ov = ref(overlayRef), btn = ref(btnRef);
        if (realTabs == null || ov == null) return;
        if (SystemClock.uptimeMillis() - lastClick > 800) {
            int found = -1;
            for (int i = 0; i < realTabs.size(); i++) {
                View c = realTabs.get(i).get();
                if (c == null) continue;
                if (isSel(c, 0)) { if (found != -1) { found = -2; break; } found = i; }
            }
            if (found >= 0 && found != prevSel) { prevSel = found; setSel(found, true); }
        }
        int col = barColor(nav, host);
        int theme = (col != 0 && lum(col) > 0.5f) ? 1 : 0;
        if (theme != lastTheme) {
            lastTheme = theme;
            int content = theme == 1 ? 0xFF161823 : 0xFFFFFFFF;
            int surface = theme == 1 ? 0x80FFFFFF : 0x66000000;
            try {
                mSetContent.invoke(ov, content);
                mSetContainer.invoke(ov, surface);
            } catch (Throwable t) { XposedBridge.log(t); }
            if (btn != null) {
                opt(btn, "setContentColor", int.class, content);
                opt(btn, "setSurfaceColor", int.class, surface);
                opt(btn, "setButtonSurfaceColor", int.class, surface);
            }
        }
    }

    // ---------- 个人菜单动态玻璃：兼容 FrameLayout / LinearLayout 卡片容器 ----------

    static void scanMenuCards(Activity a, View root) {
        if (!(root instanceof ViewGroup)) return;
        try {
            ClassLoader cl = loadLib(a);
            if (cl == null) {
                XposedBridge.log("DyUI menu glass: LiquidGlass library unavailable: " + libError);
                return;
            }
            Class<?> buttonClass = cl.loadClass(LG + "LiquidButton");
            int sw = a.getResources().getDisplayMetrics().widthPixels;
            int sh = a.getResources().getDisplayMetrics().heightPixels;
            scanMenuNode(a, (ViewGroup) root, root, buttonClass, sw, sh);
            for (int i = menuGlassRecords.size() - 1; i >= 0; i--) {
                MenuGlassRecord r = menuGlassRecords.get(i);
                if (r.wrapper.get() == null || r.original.get() == null || r.parent.get() == null)
                    menuGlassRecords.remove(i);
            }
        } catch (Throwable t) {
            XposedBridge.log("DyUI menu glass scan: " + t);
        }
    }

    static void scanMenuNode(Activity a, ViewGroup group, View decor, Class<?> buttonClass, int sw, int sh) {
        // Iterate backwards because a matching child may be wrapped in-place.
        for (int i = group.getChildCount() - 1; i >= 0; i--) {
            View child = group.getChildAt(i);
            if (OVERLAY_TAG.equals(child.getTag())) continue;

            boolean supportedParent = group instanceof FrameLayout || group instanceof LinearLayout;
            boolean candidate = supportedParent
                    && child instanceof ViewGroup
                    && child != decor
                    && child.getTag() == null
                    && ((ViewGroup) child).getChildCount() > 0
                    && child.getWidth() >= sw * 0.48f
                    && child.getHeight() >= dp(a, 72)
                    && child.getHeight() <= sh * 0.78f;

            if (candidate) {
                int[] xy = new int[2];
                child.getLocationOnScreen(xy);
                candidate = xy[0] >= sw * 0.08f
                        && xy[1] >= dp(a, 48)
                        && xy[1] <= sh * 0.90f;
            }

            if (candidate && !hasMenuGlass(child)) {
                ViewGroup original = (ViewGroup) child;
                try {
                    ViewGroup.LayoutParams oldParams = original.getLayoutParams();
                    int index = group.indexOfChild(original);
                    Drawable oldBackground = original.getBackground();

                    // A FrameLayout wrapper lets the glass sit between the card background
                    // and its original content without changing LinearLayout measurement.
                    FrameLayout wrapper = new FrameLayout(original.getContext());
                    wrapper.setTag(OVERLAY_TAG);
                    wrapper.setClipChildren(false);
                    wrapper.setClipToPadding(false);
                    if (oldBackground != null) wrapper.setBackground(oldBackground);
                    original.setBackground(null);

                    group.removeViewAt(index);
                    wrapper.addView(original, new FrameLayout.LayoutParams(-1, -1));

                    Context sctx = scaledCtx(a, SCALE);
                    View glass = (View) buttonClass.getConstructor(Context.class).newInstance(sctx);
                    buttonClass.getMethod("setAutoBackdropEnabled", boolean.class).invoke(glass, true);
                    opt(glass, "setAutoBackdropContinuous", boolean.class, true);
                    opt(glass, "setText", CharSequence.class, "");
                    opt(glass, "setCornerRadiusDp", float.class, 24f);
                    opt(glass, "setBlurRadiusDp", float.class, 18f);
                    opt(glass, "setBackdropOpacity", float.class, 1f);
                    opt(glass, "setSurfaceColor", int.class, isNight(a) ? 0x66202028 : 0x66FFFFFF);
                    opt(glass, "setButtonSurfaceColor", int.class, isNight(a) ? 0x66202028 : 0x66FFFFFF);
                    glass.setTag(OVERLAY_TAG);
                    glass.setClickable(false);
                    glass.setFocusable(false);
                    glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                    glass.setElevation(0f);

                    // Draw glass first; the original menu rows/text remain above it.
                    wrapper.addView(glass, 0, new FrameLayout.LayoutParams(-1, -1));
                    group.addView(wrapper, index, oldParams);
                    menuGlassRecords.add(new MenuGlassRecord(group, wrapper, original, oldParams, index));
                    menuGlassTargets.add(new WeakReference<>(wrapper));

                    // Continue scanning inside the original card for nested card groups.
                    scanMenuNode(a, original, decor, buttonClass, sw, sh);
                    continue;
                } catch (Throwable t) {
                    XposedBridge.log("DyUI menu glass card: " + t);
                    // If wrapping failed part-way, avoid leaving a detached original view.
                    try {
                        if (original.getParent() == null) {
                            group.addView(original, Math.min(i, group.getChildCount()));
                        }
                    } catch (Throwable ignored) { }
                }
            }

            if (child instanceof ViewGroup) {
                scanMenuNode(a, (ViewGroup) child, decor, buttonClass, sw, sh);
            }
        }
    }

    static boolean hasMenuGlass(View v) {
        if (OVERLAY_TAG.equals(v.getTag())) return true;
        for (MenuGlassRecord r : menuGlassRecords) {
            if (r.original.get() == v || r.wrapper.get() == v) return true;
        }
        return false;
    }

    static void removeMenuGlass() {
        for (int i = menuGlassRecords.size() - 1; i >= 0; i--) {
            MenuGlassRecord r = menuGlassRecords.get(i);
            ViewGroup parent = r.parent.get();
            ViewGroup wrapper = r.wrapper.get();
            View original = r.original.get();
            if (parent == null || wrapper == null || original == null) continue;
            try {
                int index = parent.indexOfChild(wrapper);
                if (index < 0) continue;
                Drawable background = wrapper.getBackground();
                parent.removeViewAt(index);
                wrapper.removeView(original);
                original.setBackground(background);
                parent.addView(original, Math.min(index, parent.getChildCount()), r.params);
            } catch (Throwable t) {
                XposedBridge.log("DyUI menu glass restore: " + t);
            }
        }
        menuGlassRecords.clear();
        menuGlassTargets.clear();
    }

    static void setSel(int i, boolean animate) {
        View ov = ref(overlayRef);
        if (ov == null || mSetSel == null) return;
        syncing = true;
        try { mSetSel.invoke(ov, i, animate); }
        catch (Throwable t) { XposedBridge.log(t); }
        finally { syncing = false; }
    }

    // 用户点了玻璃导航栏的某个 tab：转发给对应的原 tab
    static void onSelected(int idx) {
        if (syncing || realTabs == null || idx < 0 || idx >= realTabs.size()) return;
        lastClick = SystemClock.uptimeMillis();
        prevSel = idx;
        View real = realTabs.get(idx).get();
        if (real != null) clickReal(real);
    }

    static void clickReal(View tab) {
        try {
            if (tab.hasOnClickListeners()) { tab.performClick(); return; }
            long t = SystemClock.uptimeMillis();
            float x = tab.getWidth() / 2f, y = tab.getHeight() / 2f;
            MotionEvent dn = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
            MotionEvent up = MotionEvent.obtain(t, t + 40, MotionEvent.ACTION_UP, x, y, 0);
            tab.dispatchTouchEvent(dn);
            tab.dispatchTouchEvent(up);
            dn.recycle();
            up.recycle();
        } catch (Throwable e) { XposedBridge.log(e); }
    }

    static boolean isSel(View v, int d) {
        if (v.isSelected()) return true;
        if (d < 3 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (isSel(g.getChildAt(i), d + 1)) return true;
        }
        return false;
    }

    static String labelOf(View tab) {
        if (tab.getClass().getName().contains("PublishButton")) return "＋";
        String s = firstText(tab, 0);
        return s == null ? "·" : s;
    }

    static String firstText(View v, int d) {
        if (v instanceof TextView) {
            String c = String.valueOf(((TextView) v).getText()).trim();
            if (!c.isEmpty() && c.length() <= 6 && !c.matches("\\d+\\+?")) return c;
        }
        if (v instanceof ViewGroup && d < 8) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                String r = firstText(g.getChildAt(i), d + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    static float lum(int c) {
        return (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f;
    }

    // 原底栏当前的底色（抖音首页深色、其他页浅色），用来决定玻璃是深色还是浅色
    static int barColor(ViewGroup nav, View host) {
        ArrayList<View> chain = new ArrayList<>();
        for (View v = nav; v != null; v = (v == host || !(v.getParent() instanceof View)) ? null : (View) v.getParent())
            chain.add(v);
        for (int i = chain.size() - 1; i >= 0; i--) {
            Drawable d = chain.get(i).getBackground();
            if (d instanceof ColorDrawable && Color.alpha(((ColorDrawable) d).getColor()) > 0)
                return ((ColorDrawable) d).getColor();
        }
        return 0;
    }

    static void removeNav0() {
        View ov = ref(overlayRef), host = ref(hostRef), btn = ref(btnRef);
        try {
            if (ov != null && ov.getParent() instanceof ViewGroup) ((ViewGroup) ov.getParent()).removeView(ov);
            if (btn != null && btn.getParent() instanceof ViewGroup) ((ViewGroup) btn.getParent()).removeView(btn);
        } catch (Throwable t) { XposedBridge.log(t); }
        try { if (host != null) host.setClipBounds(null); } catch (Throwable ignored) { }
        overlayRef = null;
        btnRef = null;
        hasBtn = false;
        hostRef = null;
        navRef = null;
        realTabs = null;
        lastTheme = -1;
    }

    static void removeNav() {
        glassEnabled = false;
        menuGlassEnabled = false;
        View dec = ref(glassDecorRef);
        try {
            if (dec != null && glassListener != null) dec.getViewTreeObserver().removeOnPreDrawListener(glassListener);
        } catch (Throwable ignored) { }
        glassListener = null;
        glassDecorRef = null;
        removeNav0();
        removeMenuGlass();
    }

    // 底部导航 = “首页”和“我”两个文字的公共父容器（要求位于屏幕下方）
    static ViewGroup findNav(View decor) {
        int h = decor.getResources().getDisplayMetrics().heightPixels;
        View home = findTextBottom(decor, "首页", h), me = findTextBottom(decor, "我", h);
        if (home == null || me == null) return null;
        return lca(home, me);
    }

    static View findTextBottom(View v, String t, int screenH) {
        if (OVERLAY_TAG.equals(v.getTag())) return null;
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) {
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);
                if (loc[1] > screenH * 0.75f) return v;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findTextBottom(g.getChildAt(i), t, screenH);
                if (r != null) return r;
            }
        }
        return null;
    }

    static void dumpView(StringBuilder sb, View v, int depth, int max) {
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName()).append(' ').append(v.getWidth()).append('x').append(v.getHeight());
        if (v instanceof TextView) sb.append(" \"").append(((TextView) v).getText()).append('"');
        if (v.getId() > 0) {
            try { sb.append(" id=").append(v.getResources().getResourceEntryName(v.getId())); }
            catch (Throwable ignored) { }
        }
        sb.append('\n');
        if (depth < max && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpView(sb, g.getChildAt(i), depth + 1, max);
        }
    }

    static void copyDiag(Activity a) {
        Activity m = mainRef == null ? null : mainRef.get();
        if (m == null) {
            Toast.makeText(a, "请先回到抖音首页，再进来点一次", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder("DyUI diag\n");
        try {
            sb.append("douyin=").append(m.getPackageManager().getPackageInfo(HOST, 0).versionName).append('\n');
        } catch (Throwable ignored) { }
        sb.append("activity=").append(m.getClass().getName()).append('\n');
        ViewGroup nav = findNav(m.getWindow().getDecorView());
        if (nav == null) {
            sb.append("nav=not found\n");
        } else {
            sb.append("nav parents:\n");
            int k = 0;
            for (ViewParent p = nav.getParent(); p instanceof View && k < 5; p = p.getParent(), k++) {
                View pv = (View) p;
                sb.append("  ").append(pv.getClass().getName()).append(' ')
                        .append(pv.getWidth()).append('x').append(pv.getHeight()).append('\n');
            }
            sb.append("nav tree:\n");
            dumpView(sb, nav, 0, 4);
        }
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("dyui", sb.toString()));
        Toast.makeText(a, "已复制，粘贴发给我即可", Toast.LENGTH_LONG).show();
    }

    // ---------- 美化功能（示例：按文字隐藏控件，更多功能加在这里） ----------

    static void applyBeautify(Activity a, View root) {
        SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        if (!sp.getBoolean("enabled", true)) return;
        String kw = sp.getString("hide_keywords", "").trim();
        if (kw.isEmpty()) return;
        walk(root, kw.split("[,，]"));
    }

    static void walk(View v, String[] kws) {
        if (TAG.equals(v.getTag()) || OVERLAY_TAG.equals(v.getTag())) return;
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null) for (String k : kws) {
                if (!k.trim().isEmpty() && s.toString().contains(k.trim())) {
                    v.setVisibility(View.GONE);
                    break;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), kws);
        }
    }

    static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
