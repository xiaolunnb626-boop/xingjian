package com.example.dyui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String HOST = "com.ss.android.ugc.aweme";
    static final String TAG = "dyui_entry";
    // 用设置页里两个固定文字定位列表容器，不依赖混淆后的类名/ID
    static final String ANCHOR1 = "账号与安全";
    static final String ANCHOR2 = "通用设置";
    static boolean toasted = false;
    static boolean posUnsupported = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!HOST.equals(lpp.packageName)) return;
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    final Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow().getDecorView();
                    if (!a.getClass().getName().contains("MainActivity")) tryInject(a, decor, 0);
                    decor.postDelayed(() -> applyBeautify(a, decor), 600);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    // ---------- 注入设置页顶部入口 ----------

    static void tryInject(final Activity a, final View decor, final int n) {
        if (n > 8 || decor.findViewWithTag(TAG) != null) return;
        decor.postDelayed(() -> {
            try {
                if (decor.findViewWithTag(TAG) != null) return;
                View t1 = findText(decor, ANCHOR1), t2 = findText(decor, ANCHOR2);
                if (t1 == null || t2 == null) { tryInject(a, decor, n + 1); return; }
                if (!toasted) {
                    toasted = true;
                    Toast.makeText(a, "抖音美化：启动成功", Toast.LENGTH_LONG).show();
                }
                ViewGroup box = lca(t1, t2);
                if (box == null) { XposedBridge.log("DyUI: container not found"); return; }
                inject(a, box);
            } catch (Throwable t) { XposedBridge.log(t); }
        }, 300);
    }

    static void inject(Activity a, ViewGroup box) {
        XposedBridge.log("DyUI: container=" + box.getClass().getName());
        int h = dp(a, 74);
        if (box instanceof LinearLayout && ((LinearLayout) box).getOrientation() == LinearLayout.VERTICAL) {
            box.addView(buildEntry(a), 0, new LinearLayout.LayoutParams(-1, h));
        } else if (isRecycler(box) && box.getParent() instanceof ViewGroup) {
            overlay(a, box, h);
        } else {
            XposedBridge.log("DyUI: unsupported container " + box.getClass().getName());
        }
    }

    // RecyclerView：在其上方叠一个入口，并跟随列表滚动
    static void overlay(Activity a, final ViewGroup rv, final int h) {
        ViewGroup parent = (ViewGroup) rv.getParent();
        final View e = buildEntry(a);
        if (parent instanceof LinearLayout && ((LinearLayout) parent).getOrientation() == LinearLayout.VERTICAL) {
            parent.addView(e, parent.indexOfChild(rv), new LinearLayout.LayoutParams(-1, h));
            return;
        }
        rv.setPadding(rv.getPaddingLeft(), rv.getPaddingTop() + h, rv.getPaddingRight(), rv.getPaddingBottom());
        rv.setClipToPadding(false);
        parent.addView(e, new ViewGroup.LayoutParams(-1, h));
        rv.getViewTreeObserver().addOnPreDrawListener(() -> {
            try { sync(rv, e, h); } catch (Throwable ignored) { }
            return true;
        });
    }

    static void sync(ViewGroup rv, View e, int h) {
        float base = rv.getTop();
        if (!posUnsupported) {
            try {
                for (int i = 0; i < rv.getChildCount(); i++) {
                    View c = rv.getChildAt(i);
                    Object pos = XposedHelpers.callMethod(rv, "getChildAdapterPosition", c);
                    if (pos instanceof Integer && (Integer) pos == 0) {
                        e.setVisibility(View.VISIBLE);
                        e.setTranslationY(base + c.getTop() - h);
                        return;
                    }
                }
                e.setVisibility(View.INVISIBLE);
                return;
            } catch (Throwable t) { posUnsupported = true; }
        }
        // 兜底：取不到位置时，只在列表顶部显示
        e.setVisibility(rv.canScrollVertically(-1) ? View.INVISIBLE : View.VISIBLE);
        e.setTranslationY(base);
    }

    static boolean isRecycler(View v) {
        for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass())
            if (c.getName().contains("RecyclerView")) return true;
        return false;
    }

    static View findText(View v, String t) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) return v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findText(g.getChildAt(i), t);
                if (r != null) return r;
            }
        }
        return null;
    }

    // 两个文字的最近公共父容器 = 整个设置列表
    static ViewGroup lca(View a, View b) {
        Set<ViewParent> s = new HashSet<>();
        for (ViewParent p = a.getParent(); p != null; p = p.getParent()) s.add(p);
        for (ViewParent p = b.getParent(); p != null; p = p.getParent())
            if (p instanceof ViewGroup && s.contains(p)) return (ViewGroup) p;
        return null;
    }

    // ---------- 入口卡片（仿设置页的圆角白卡片） ----------

    static View buildEntry(final Activity a) {
        boolean night = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        FrameLayout wrap = new FrameLayout(a);
        wrap.setTag(TAG);
        wrap.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(night ? Color.parseColor("#252525") : Color.WHITE);
        bg.setCornerRadius(dp(a, 12));
        card.setBackground(bg);

        TextView icon = new TextView(a);
        icon.setText("\uD83C\uDFA8");
        icon.setTextSize(20);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-2, -2);
        ilp.rightMargin = dp(a, 12);
        card.addView(icon, ilp);

        TextView t = new TextView(a);
        t.setText("抖音美化");
        t.setTextSize(16);
        t.setTextColor(night ? Color.parseColor("#E8E8E8") : Color.parseColor("#161823"));
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView arrow = new TextView(a);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(Color.parseColor("#9A9A9A"));
        card.addView(arrow);

        wrap.addView(card, new FrameLayout.LayoutParams(-1, -1));
        wrap.setOnClickListener(v -> showPanel(a));
        return wrap;
    }

    // ---------- 设置面板（在抖音内弹出，配置存在抖音自己的 SharedPreferences） ----------

    static void showPanel(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), 0);

        TextView st = new TextView(a);
        st.setText("● 模块运行中，启动成功");
        st.setTextColor(Color.parseColor("#2E9E5B"));
        box.addView(st);

        final Switch sw = new Switch(a);
        sw.setText("启用美化");
        sw.setChecked(sp.getBoolean("enabled", true));
        box.addView(sw);

        TextView tip = new TextView(a);
        tip.setText("\n隐藏包含以下文字的控件（逗号分隔）：");
        box.addView(tip);

        final EditText et = new EditText(a);
        et.setText(sp.getString("hide_keywords", ""));
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(a)
                .setTitle("抖音美化")
                .setView(box)
                .setPositiveButton("保存", (d, w) -> {
                    sp.edit().putBoolean("enabled", sw.isChecked())
                            .putString("hide_keywords", et.getText().toString()).apply();
                    Toast.makeText(a, "已保存，重新进入页面后生效", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------- 美化功能（示例：按文字隐藏控件，更多功能加在这里） ----------

    static void applyBeautify(Activity a, View root) {
        SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        if (!sp.getBoolean("enabled", true)) return;
        String kw = sp.getString("hide_keywords", "").trim();
        if (kw.isEmpty()) return;
        walk(root, kw.split("[,，]"));
    }

    static void walk(View v, String[] kws) {
        if (TAG.equals(v.getTag())) return;
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null) for (String k : kws) {
                if (!k.trim().isEmpty() && s.toString().contains(k.trim())) {
                    v.setVisibility(View.GONE);
                    break;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), kws);
        }
    }

    static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
