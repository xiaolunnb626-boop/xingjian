package com.example.dyui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String HOST = "com.ss.android.ugc.aweme";
    static final String TAG = "dyui_entry";
    // 用设置页里两个固定文字定位列表容器，不依赖混淆后的类名/ID
    static final String ANCHOR1 = "账号与安全";
    static final String ANCHOR2 = "通用设置";
    static boolean toasted = false;
    static boolean posUnsupported = false;
    static boolean navToasted = false;
    static WeakReference<Activity> mainRef;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!HOST.equals(lpp.packageName)) return;
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    final Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow().getDecorView();
                    if (a.getClass().getName().contains("MainActivity")) {
                        mainRef = new WeakReference<>(a);
                        decor.postDelayed(() -> checkNav(a, decor), 1500);
                    } else {
                        tryInject(a, decor, 0);
                    }
                    decor.postDelayed(() -> applyBeautify(a, decor), 600);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    // ---------- 注入设置页顶部入口 ----------

    static void tryInject(final Activity a, final View decor, final int n) {
        if (n > 8 || decor.findViewWithTag(TAG) != null) return;
        decor.postDelayed(() -> {
            try {
                if (decor.findViewWithTag(TAG) != null) return;
                View t1 = findText(decor, ANCHOR1), t2 = findText(decor, ANCHOR2);
                if (t1 == null || t2 == null) { tryInject(a, decor, n + 1); return; }
                if (!toasted) {
                    toasted = true;
                    Toast.makeText(a, "抖音美化：启动成功", Toast.LENGTH_LONG).show();
                }
                ViewGroup box = lca(t1, t2);
                if (box == null) { XposedBridge.log("DyUI: container not found"); return; }
                inject(a, box);
            } catch (Throwable t) { XposedBridge.log(t); }
        }, 300);
    }

    static void inject(Activity a, ViewGroup box) {
        XposedBridge.log("DyUI: container=" + box.getClass().getName());
        int h = dp(a, 74);
        if (box instanceof LinearLayout && ((LinearLayout) box).getOrientation() == LinearLayout.VERTICAL) {
            box.addView(buildEntry(a), 0, new LinearLayout.LayoutParams(-1, h));
        } else if (isRecycler(box) && box.getParent() instanceof ViewGroup) {
            overlay(a, box, h);
        } else {
            XposedBridge.log("DyUI: unsupported container " + box.getClass().getName());
        }
    }

    // RecyclerView：在其上方叠一个入口，并跟随列表滚动
    static void overlay(Activity a, final ViewGroup rv, final int h) {
        ViewGroup parent = (ViewGroup) rv.getParent();
        final View e = buildEntry(a);
        if (parent instanceof LinearLayout && ((LinearLayout) parent).getOrientation() == LinearLayout.VERTICAL) {
            parent.addView(e, parent.indexOfChild(rv), new LinearLayout.LayoutParams(-1, h));
            return;
        }
        rv.setPadding(rv.getPaddingLeft(), rv.getPaddingTop() + h, rv.getPaddingRight(), rv.getPaddingBottom());
        rv.setClipToPadding(false);
        parent.addView(e, new ViewGroup.LayoutParams(-1, h));
        rv.getViewTreeObserver().addOnPreDrawListener(() -> {
            try { sync(rv, e, h); } catch (Throwable ignored) { }
            return true;
        });
    }

    static void sync(ViewGroup rv, View e, int h) {
        float base = rv.getTop();
        if (!posUnsupported) {
            try {
                for (int i = 0; i < rv.getChildCount(); i++) {
                    View c = rv.getChildAt(i);
                    Object pos = XposedHelpers.callMethod(rv, "getChildAdapterPosition", c);
                    if (pos instanceof Integer && (Integer) pos == 0) {
                        e.setVisibility(View.VISIBLE);
                        e.setTranslationY(base + c.getTop() - h);
                        return;
                    }
                }
                e.setVisibility(View.INVISIBLE);
                return;
            } catch (Throwable t) { posUnsupported = true; }
        }
        // 兜底：取不到位置时，只在列表顶部显示
        e.setVisibility(rv.canScrollVertically(-1) ? View.INVISIBLE : View.VISIBLE);
        e.setTranslationY(base);
    }

    static boolean isRecycler(View v) {
        for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass())
            if (c.getName().contains("RecyclerView")) return true;
        return false;
    }

    static View findText(View v, String t) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) return v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findText(g.getChildAt(i), t);
                if (r != null) return r;
            }
        }
        return null;
    }

    // 两个文字的最近公共父容器 = 整个设置列表
    static ViewGroup lca(View a, View b) {
        Set<ViewParent> s = new HashSet<>();
        for (ViewParent p = a.getParent(); p != null; p = p.getParent()) s.add(p);
        for (ViewParent p = b.getParent(); p != null; p = p.getParent())
            if (p instanceof ViewGroup && s.contains(p)) return (ViewGroup) p;
        return null;
    }

    // ---------- 入口卡片（仿设置页的圆角白卡片） ----------

    static View buildEntry(final Activity a) {
        boolean night = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        FrameLayout wrap = new FrameLayout(a);
        wrap.setTag(TAG);
        wrap.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(night ? Color.parseColor("#252525") : Color.WHITE);
        bg.setCornerRadius(dp(a, 12));
        card.setBackground(bg);

        TextView t = new TextView(a);
        t.setText("抖音美化");
        t.setTextSize(16);
        t.setTextColor(night ? Color.parseColor("#E8E8E8") : Color.parseColor("#161823"));
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        wrap.addView(card, new FrameLayout.LayoutParams(-1, -1));
        wrap.setOnClickListener(v -> showMain(a));
        return wrap;
    }

    // ---------- 功能列表页（全屏页面，仿设置页风格） ----------

    static boolean isNight(Activity a) {
        return (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static TextView tv(Activity a, String s, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static Dialog page(final Activity a, String title, View... sections) {
        boolean n = isNight(a);
        final Dialog d = new Dialog(a, n ? android.R.style.Theme_Material_NoActionBar
                : android.R.style.Theme_Material_Light_NoActionBar);
        int bg = n ? 0xFF121212 : 0xFFF4F4F4;
        int fg = n ? 0xFFE8E8E8 : 0xFF161823;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        FrameLayout bar = new FrameLayout(a);
        TextView tt = tv(a, title, 17, fg);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        bar.addView(tt, new FrameLayout.LayoutParams(-1, -1));
        TextView back = tv(a, "‹", 30, fg);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> d.dismiss());
        bar.addView(back, new FrameLayout.LayoutParams(dp(a, 56), -1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(a, 52)));

        ScrollView sv = new ScrollView(a);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 24));
        for (View v : sections) list.addView(v);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(-1, -1);
            w.setStatusBarColor(bg);
            w.setNavigationBarColor(bg);
            w.getDecorView().setSystemUiVisibility(n ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        d.show();
        return d;
    }

    static LinearLayout card(Activity a) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(isNight(a) ? 0xFF252525 : 0xFFFFFFFF);
        g.setCornerRadius(dp(a, 12));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(a, 12);
        c.setLayoutParams(lp);
        return c;
    }

    static void addRow(Activity a, LinearLayout card, String text, View trailing, final Runnable click) {
        boolean n = isNight(a);
        if (card.getChildCount() > 0) {
            View dv = new View(a);
            dv.setBackgroundColor(n ? 0x22FFFFFF : 0x14000000);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.leftMargin = dp(a, 16);
            card.addView(dv, dl);
        }
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        r.addView(tv(a, text, 16, n ? 0xFFE8E8E8 : 0xFF161823), new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) r.addView(trailing);
        if (click != null) r.setOnClickListener(v -> click.run());
        card.addView(r, new LinearLayout.LayoutParams(-1, dp(a, 56)));
    }

    static View arrow(Activity a) { return tv(a, "›", 22, 0xFF9A9A9A); }

    static void showMain(final Activity a) {
        LinearLayout c = card(a);
        addRow(a, c, "美化功能", arrow(a), () -> showBeautify(a));
        LinearLayout c2 = card(a);
        addRow(a, c2, "复制诊断信息（底部导航结构）", null, () -> copyDiag(a));
        page(a, "抖音美化", c, c2);
    }

    static void showBeautify(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout c = card(a);
        final Switch sw = new Switch(a);
        sw.setChecked(sp.getBoolean("liquid_nav", false));
        sw.setOnCheckedChangeListener((b, on) -> {
            sp.edit().putBoolean("liquid_nav", on).apply();
            Toast.makeText(a, on ? "已开启，回到首页后生效" : "已关闭", Toast.LENGTH_SHORT).show();
        });
        addRow(a, c, "1. 底部导航：液态玻璃（开发中）", sw, () -> sw.toggle());
        addRow(a, c, "2. 隐藏指定文字的控件", arrow(a), () -> showHide(a));
        page(a, "美化功能", c);
    }

    static void showHide(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), 0);

        final Switch sw = new Switch(a);
        sw.setText("启用");
        sw.setChecked(sp.getBoolean("enabled", true));
        box.addView(sw);

        TextView tip = new TextView(a);
        tip.setText("\n隐藏包含以下文字的控件（逗号分隔）：");
        box.addView(tip);

        final EditText et = new EditText(a);
        et.setText(sp.getString("hide_keywords", ""));
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(a)
                .setTitle("隐藏指定文字的控件")
                .setView(box)
                .setPositiveButton("保存", (d, w) -> {
                    sp.edit().putBoolean("enabled", sw.isChecked())
                            .putString("hide_keywords", et.getText().toString()).apply();
                    Toast.makeText(a, "已保存，重新进入页面后生效", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------- 底部导航：定位 + 诊断（液态玻璃的前置步骤） ----------

    static void checkNav(Activity a, View decor) {
        try {
            SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
            if (!sp.getBoolean("liquid_nav", false) || navToasted) return;
            ViewGroup nav = findNav(decor);
            if (nav != null) {
                navToasted = true;
                Toast.makeText(a, "已识别底部导航（液态玻璃开发中）", Toast.LENGTH_LONG).show();
            }
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    // 底部导航 = “首页”和“我”两个文字的公共父容器（要求位于屏幕下方）
    static ViewGroup findNav(View decor) {
        int h = decor.getResources().getDisplayMetrics().heightPixels;
        View home = findTextBottom(decor, "首页", h), me = findTextBottom(decor, "我", h);
        if (home == null || me == null) return null;
        return lca(home, me);
    }

    static View findTextBottom(View v, String t, int screenH) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) {
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);
                if (loc[1] > screenH * 0.75f) return v;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findTextBottom(g.getChildAt(i), t, screenH);
                if (r != null) return r;
            }
        }
        return null;
    }

    static void dumpView(StringBuilder sb, View v, int depth, int max) {
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName()).append(' ').append(v.getWidth()).append('x').append(v.getHeight());
        if (v instanceof TextView) sb.append(" \"").append(((TextView) v).getText()).append('"');
        if (v.getId() > 0) {
            try { sb.append(" id=").append(v.getResources().getResourceEntryName(v.getId())); }
            catch (Throwable ignored) { }
        }
        sb.append('\n');
        if (depth < max && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpView(sb, g.getChildAt(i), depth + 1, max);
        }
    }

    static void copyDiag(Activity a) {
        Activity m = mainRef == null ? null : mainRef.get();
        if (m == null) {
            Toast.makeText(a, "请先回到抖音首页，再进来点一次", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder("DyUI diag\n");
        try {
            sb.append("douyin=").append(m.getPackageManager().getPackageInfo(HOST, 0).versionName).append('\n');
        } catch (Throwable ignored) { }
        sb.append("activity=").append(m.getClass().getName()).append('\n');
        ViewGroup nav = findNav(m.getWindow().getDecorView());
        if (nav == null) {
            sb.append("nav=not found\n");
        } else {
            sb.append("nav parents:\n");
            int k = 0;
            for (ViewParent p = nav.getParent(); p instanceof View && k < 5; p = p.getParent(), k++) {
                View pv = (View) p;
                sb.append("  ").append(pv.getClass().getName()).append(' ')
                        .append(pv.getWidth()).append('x').append(pv.getHeight()).append('\n');
            }
            sb.append("nav tree:\n");
            dumpView(sb, nav, 0, 4);
        }
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("dyui", sb.toString()));
        Toast.makeText(a, "已复制，粘贴发给我即可", Toast.LENGTH_LONG).show();
    }

    // ---------- 美化功能（示例：按文字隐藏控件，更多功能加在这里） ----------

    static void applyBeautify(Activity a, View root) {
        SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        if (!sp.getBoolean("enabled", true)) return;
        String kw = sp.getString("hide_keywords", "").trim();
        if (kw.isEmpty()) return;
        walk(root, kw.split("[,，]"));
    }

    static void walk(View v, String[] kws) {
        if (TAG.equals(v.getTag())) return;
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null) for (String k : kws) {
                if (!k.trim().isEmpty() && s.toString().contains(k.trim())) {
                    v.setVisibility(View.GONE);
                    break;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), kws);
        }
    }

    static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
