package com.example.dyui;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String HOST = "com.ss.android.ugc.aweme";
    static final String SELF = "com.example.dyui";
    static final String TAG = "dyui_entry";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!HOST.equals(lpp.packageName)) return;

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Activity a = (Activity) param.thisObject;
                    View decor = a.getWindow().getDecorView();
                    // 设置页类名随版本变化，用 jadx 确认后改这里
                    if (a.getClass().getName().contains("SettingContainerActivity")) {
                        tryInject(a, decor, 0);
                    }
                    decor.postDelayed(() -> applyBeautify(decor), 500);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    // 设置页内容是异步加载的，重试几次
    static void tryInject(Activity a, View decor, int n) {
        if (n > 8 || decor.findViewWithTag(TAG) != null) return;
        decor.postDelayed(() -> {
            ViewGroup target = findTarget(decor);
            if (target == null) { tryInject(a, decor, n + 1); return; }
            target.addView(buildEntry(a), 0);
        }, 300);
    }

    // 找设置列表容器：ScrollView 的唯一子 LinearLayout，或 RecyclerView 的竖向 LinearLayout 父容器
    static ViewGroup findTarget(View v) {
        if (v instanceof ScrollView) {
            View c = ((ViewGroup) v).getChildAt(0);
            if (c instanceof LinearLayout) return (ViewGroup) c;
        }
        if (v.getClass().getName().contains("RecyclerView")
                && v.getParent() instanceof LinearLayout
                && ((LinearLayout) v.getParent()).getOrientation() == LinearLayout.VERTICAL) {
            return (ViewGroup) v.getParent();
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                ViewGroup r = findTarget(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    static View buildEntry(Activity a) {
        float d = a.getResources().getDisplayMetrics().density;
        LinearLayout row = new LinearLayout(a);
        row.setTag(TAG);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding((int) (16 * d), 0, (int) (16 * d), 0);
        row.setBackgroundColor(Color.TRANSPARENT);

        TextView t = new TextView(a);
        t.setText("抖音美化");
        t.setTextSize(16);
        t.setTextColor(Color.parseColor("#888888"));
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView arrow = new TextView(a);
        arrow.setText("›");
        arrow.setTextSize(20);
        row.addView(arrow);

        row.setLayoutParams(new ViewGroup.LayoutParams(-1, (int) (56 * d)));
        row.setOnClickListener(v -> {
            Intent i = new Intent();
            i.setComponent(new ComponentName(SELF, SELF + ".SettingsActivity"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        });
        return row;
    }

    // 示例功能：按文字关键字隐藏控件，其他美化项都可以加在这里
    static void applyBeautify(View root) {
        XSharedPreferences sp = new XSharedPreferences(SELF, "settings");
        sp.reload();
        if (!sp.getBoolean("enabled", true)) return;
        String kw = sp.getString("hide_keywords", "").trim();
        if (kw.isEmpty()) return;
        walk(root, kw.split("[,，]"));
    }

    static void walk(View v, String[] kws) {
        if (v instanceof TextView && v.getTag() != TAG) {
            CharSequence s = ((TextView) v).getText();
            if (s != null) for (String k : kws) {
                if (!k.trim().isEmpty() && s.toString().contains(k.trim())) {
                    v.setVisibility(View.GONE);
                    break;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), kws);
        }
    }
}
