package com.example.fightmod;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import java.lang.reflect.Method;
import java.util.*;

import dalvik.system.DexFile;
import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 作用域里勾选哪个游戏就对哪个生效。
 * 进游戏后出现悬浮窗：搜索方法 → 选为"伤害"/"间隔" → 拖滑条改倍率。
 */
public class MainHook implements IXposedHookLoadPackage {

    static volatile boolean enabled = true;
    static volatile float dmgMul = 1f, cdMul = 1f;
    static String dmgTarget = "", cdTarget = "";
    static ClassLoader gameCl;
    static boolean inited = false;
    static View panel;
    static SharedPreferences sp;
    static final Map<String, Set<XC_MethodHook.Unhook>> hooks = new HashMap<>();
    static final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp.packageName.equals("android") || lp.packageName.equals("com.example.fightmod")) return;
        gameCl = lp.classLoader;
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                Activity a = (Activity) p.thisObject;
                init(a);
                showPanel(a);
            }
        });
    }

    static void init(Activity a) {
        if (inited) return;
        inited = true;
        sp = a.getSharedPreferences("fightmod", 0);
        dmgTarget = sp.getString("dmg", "");
        cdTarget = sp.getString("cd", "");
        dmgMul = sp.getFloat("dmgMul", 1f);
        cdMul = sp.getFloat("cdMul", 1f);
        apply("d", dmgTarget);
        apply("c", cdTarget);
    }

    /** target 形如 com.xxx.Fighter#calcDamage ；key: d=伤害 c=间隔 */
    static void apply(String key, String target) {
        Set<XC_MethodHook.Unhook> old = hooks.remove(key);
        if (old != null) for (XC_MethodHook.Unhook u : old) u.unhook();
        if (target == null || !target.contains("#")) return;
        String[] t = target.split("#", 2);
        final boolean isDmg = key.equals("d");
        try {
            Set<XC_MethodHook.Unhook> s = XposedBridge.hookAllMethods(
                XposedHelpers.findClass(t[0], gameCl), t[1], new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        if (!enabled) return;
                        Object r = p.getResult();
                        float k = isDmg ? dmgMul : cdMul;
                        if (r instanceof Integer) p.setResult(Math.round((Integer) r * k));
                        else if (r instanceof Long) p.setResult(Math.round((Long) r * (double) k));
                        else if (r instanceof Float) p.setResult((Float) r * k);
                        else if (r instanceof Double) p.setResult((Double) r * k);
                    }
                });
            hooks.put(key, s);
        } catch (Throwable e) {
            XposedBridge.log("FightMod hook fail " + target + " : " + e);
        }
    }

    // ---------------- 搜索：在游戏 dex 里找返回数值、名字含关键字的方法 ----------------
    static List<String> search(String kw) {
        List<String> out = new ArrayList<>();
        kw = kw.toLowerCase();
        try {
            Object list = XposedHelpers.getObjectField(gameCl, "pathList");
            Object[] els = (Object[]) XposedHelpers.getObjectField(list, "dexElements");
            for (Object e : els) {
                Object df = XposedHelpers.getObjectField(e, "dexFile");
                if (df == null) continue;
                Enumeration<String> en = ((DexFile) df).entries();
                while (en.hasMoreElements() && out.size() < 80) {
                    String cn = en.nextElement();
                    if (cn.startsWith("android.") || cn.startsWith("androidx.") || cn.startsWith("kotlin")
                        || cn.startsWith("com.google.") || cn.startsWith("java.") || cn.startsWith("de.robv")) continue;
                    try {
                        Class<?> c = Class.forName(cn, false, gameCl);
                        boolean clsHit = cn.toLowerCase().contains(kw);
                        for (Method m : c.getDeclaredMethods()) {
                            Class<?> r = m.getReturnType();
                            if (!(r == int.class || r == float.class || r == double.class || r == long.class)) continue;
                            if (clsHit || m.getName().toLowerCase().contains(kw))
                                out.add(cn + "#" + m.getName() + " → " + r.getSimpleName());
                            if (out.size() >= 80) break;
                        }
                    } catch (Throwable ignore) {}
                }
            }
        } catch (Throwable t) {
            out.add("搜索失败: " + t);
        }
        return out;
    }

    // ---------------- 悬浮窗 UI ----------------
    static void showPanel(Activity a) {
        a.runOnUiThread(() -> {
            try {
                if (panel != null && panel.getParent() != null) return;
                ViewGroup root = (ViewGroup) a.getWindow().getDecorView();

                LinearLayout box = new LinearLayout(a);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setBackgroundColor(0xDD202020);
                box.setPadding(24, 16, 24, 16);

                TextView title = tv(a, "⚙ 格斗模块（点击折叠 / 拖动）");
                box.addView(title);

                LinearLayout body = new LinearLayout(a);
                body.setOrientation(LinearLayout.VERTICAL);
                box.addView(body);

                Switch sw = new Switch(a);
                sw.setText("启用"); sw.setTextColor(Color.WHITE); sw.setChecked(enabled);
                sw.setOnCheckedChangeListener((b, c) -> enabled = c);
                body.addView(sw);

                body.addView(slider(a, "伤害倍率", 0.1f, 20f, dmgMul, v -> { dmgMul = v; sp.edit().putFloat("dmgMul", v).apply(); }));
                body.addView(slider(a, "攻击间隔倍率(小=快)", 0.05f, 2f, cdMul, v -> { cdMul = v; sp.edit().putFloat("cdMul", v).apply(); }));

                TextView info = tv(a, "");
                info.setTextSize(11);
                Runnable refresh = () -> info.setText("伤害: " + (dmgTarget.isEmpty() ? "未设置" : dmgTarget)
                        + "\n间隔: " + (cdTarget.isEmpty() ? "未设置" : cdTarget));
                refresh.run();
                body.addView(info);

                Button bs = new Button(a);
                bs.setText("搜索方法");
                bs.setOnClickListener(v -> askKeyword(a, refresh));
                body.addView(bs);

                Button bc = new Button(a);
                bc.setText("清除目标");
                bc.setOnClickListener(v -> {
                    dmgTarget = ""; cdTarget = "";
                    sp.edit().remove("dmg").remove("cd").apply();
                    apply("d", ""); apply("c", ""); refresh.run();
                });
                body.addView(bc);

                final float[] d = new float[4];
                title.setOnTouchListener((v, e) -> {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            d[0] = e.getRawX() - box.getX(); d[1] = e.getRawY() - box.getY();
                            d[2] = e.getRawX(); d[3] = e.getRawY(); break;
                        case MotionEvent.ACTION_MOVE:
                            box.setX(e.getRawX() - d[0]); box.setY(e.getRawY() - d[1]); break;
                        case MotionEvent.ACTION_UP:
                            if (Math.abs(e.getRawX() - d[2]) < 10 && Math.abs(e.getRawY() - d[3]) < 10)
                                body.setVisibility(body.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                    }
                    return true;
                });

                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(620, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.leftMargin = 40; lp.topMargin = 160;
                root.addView(box, lp);
                panel = box;
            } catch (Throwable t) { XposedBridge.log(t); }
        });
    }

    static void askKeyword(Activity a, Runnable refresh) {
        EditText et = new EditText(a);
        et.setHint("关键字，如 damage / atk / hurt / interval / cd");
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(a).setTitle("搜索方法").setView(et)
            .setPositiveButton("搜索", (d, w) -> {
                String kw = et.getText().toString().trim();
                if (kw.isEmpty()) return;
                Toast.makeText(a, "搜索中…", Toast.LENGTH_SHORT).show();
                new Thread(() -> {
                    List<String> res = search(kw);
                    ui.post(() -> showResults(a, res, refresh));
                }).start();
            }).setNegativeButton("取消", null).show();
    }

    static void showResults(Activity a, List<String> res, Runnable refresh) {
        if (res.isEmpty()) { Toast.makeText(a, "没有结果，换个关键字", Toast.LENGTH_SHORT).show(); return; }
        String[] items = res.toArray(new String[0]);
        new AlertDialog.Builder(a).setTitle("选择方法（共" + items.length + "）")
            .setItems(items, (d, i) -> {
                String target = items[i].split(" → ")[0];
                new AlertDialog.Builder(a).setTitle("设为…").setMessage(target)
                    .setPositiveButton("伤害", (x, y) -> {
                        dmgTarget = target; sp.edit().putString("dmg", target).apply();
                        apply("d", target); refresh.run();
                    })
                    .setNeutralButton("攻击间隔", (x, y) -> {
                        cdTarget = target; sp.edit().putString("cd", target).apply();
                        apply("c", target); refresh.run();
                    })
                    .setNegativeButton("取消", null).show();
            }).show();
    }

    static TextView tv(Activity a, String s) {
        TextView t = new TextView(a);
        t.setText(s); t.setTextColor(Color.WHITE);
        return t;
    }

    interface OnVal { void on(float v); }

    static View slider(Activity a, String name, float min, float max, float cur, OnVal cb) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(a, name + ": " + String.format("%.2f", cur));
        SeekBar s = new SeekBar(a);
        s.setMax(100);
        s.setProgress((int) ((cur - min) / (max - min) * 100));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                float v = min + (max - min) * p / 100f;
                cb.on(v);
                t.setText(name + ": " + String.format("%.2f", v));
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(t); l.addView(s);
        return l;
    }
}
