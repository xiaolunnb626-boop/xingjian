# FightMod
LSPosed 模块：游戏内悬浮窗，修改攻击伤害与攻击间隔（仅限单机/人机对战研究）。

## 使用
1. 安装 APK，在 LSPosed 启用并勾选目标游戏。
2. 进游戏 → 悬浮窗 → 搜索方法 → 设为伤害/间隔 → 拖滑条。

## 构建
推送到 main 自动构建，APK 在 Actions → Artifacts。
打 tag（如 v1.0）会自动发布到 Releases。
