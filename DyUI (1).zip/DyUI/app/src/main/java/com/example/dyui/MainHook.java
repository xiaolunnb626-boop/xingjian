package com.example.dyui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.SystemClock;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.RenderEffect;
import android.graphics.RenderNode;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String HOST = "com.ss.android.ugc.aweme";
    static final String TAG = "dyui_entry";
    // 用设置页里两个固定文字定位列表容器，不依赖混淆后的类名/ID
    static final String ANCHOR1 = "账号与安全";
    static final String ANCHOR2 = "通用设置";
    static boolean toasted = false;
    static boolean posUnsupported = false;
    static boolean navToasted = false;
    static WeakReference<View> glassHostRef;
    static ArrayList<Object[]> savedBgs;
    static ViewTreeObserver.OnPreDrawListener glassListener;
    static boolean skipNext = false;
    static final int KEY = 0x7f7d1001;          // 给底栏相关 View 打标记，用来拦截抖音重设背景
    static boolean ownSet = false;               // 模块自己改背景时放行
    static boolean glassEnabled = false;
    static boolean glassToasted = false;
    static long lastCheck = 0;
    static WeakReference<Glass> glassRef;
    static WeakReference<Activity> glassActRef;
    static WeakReference<View> glassDecorRef;
    static WeakReference<Activity> mainRef;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!HOST.equals(lpp.packageName)) return;
        XC_MethodHook bgHook = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                if (ownSet || !(param.thisObject instanceof View)) return;
                View v = (View) param.thisObject;
                if (v.getTag(KEY) == null) return;
                // 抖音想给底栏设置背景：拦截，只把颜色记下来作为玻璃底色
                Object d = param.args[0];
                Glass g = glassRef == null ? null : glassRef.get();
                if (g != null && d instanceof ColorDrawable) g.setBase(((ColorDrawable) d).getColor());
                param.setResult(null);
            }
        };
        try {
            XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, bgHook);
            XposedHelpers.findAndHookMethod(View.class, "setBackgroundDrawable", Drawable.class, bgHook);
        } catch (Throwable t) { XposedBridge.log(t); }

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    final Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow().getDecorView();
                    if (a.getClass().getName().contains("MainActivity")) {
                        mainRef = new WeakReference<>(a);
                        decor.postDelayed(() -> applyGlass(a, decor), 800);
                    } else {
                        tryInject(a, decor, 0);
                    }
                    decor.postDelayed(() -> applyBeautify(a, decor), 600);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    // ---------- 注入设置页顶部入口 ----------

    static void tryInject(final Activity a, final View decor, final int n) {
        if (n > 8 || decor.findViewWithTag(TAG) != null) return;
        decor.postDelayed(() -> {
            try {
                if (decor.findViewWithTag(TAG) != null) return;
                View t1 = findText(decor, ANCHOR1), t2 = findText(decor, ANCHOR2);
                if (t1 == null || t2 == null) { tryInject(a, decor, n + 1); return; }
                if (!toasted) {
                    toasted = true;
                    Toast.makeText(a, "抖音美化：启动成功", Toast.LENGTH_LONG).show();
                }
                ViewGroup box = lca(t1, t2);
                if (box == null) { XposedBridge.log("DyUI: container not found"); return; }
                inject(a, box);
            } catch (Throwable t) { XposedBridge.log(t); }
        }, 300);
    }

    static void inject(Activity a, ViewGroup box) {
        XposedBridge.log("DyUI: container=" + box.getClass().getName());
        int h = dp(a, 74);
        if (box instanceof LinearLayout && ((LinearLayout) box).getOrientation() == LinearLayout.VERTICAL) {
            box.addView(buildEntry(a), 0, new LinearLayout.LayoutParams(-1, h));
        } else if (isRecycler(box) && box.getParent() instanceof ViewGroup) {
            overlay(a, box, h);
        } else {
            XposedBridge.log("DyUI: unsupported container " + box.getClass().getName());
        }
    }

    // RecyclerView：在其上方叠一个入口，并跟随列表滚动
    static void overlay(Activity a, final ViewGroup rv, final int h) {
        ViewGroup parent = (ViewGroup) rv.getParent();
        final View e = buildEntry(a);
        if (parent instanceof LinearLayout && ((LinearLayout) parent).getOrientation() == LinearLayout.VERTICAL) {
            parent.addView(e, parent.indexOfChild(rv), new LinearLayout.LayoutParams(-1, h));
            return;
        }
        rv.setPadding(rv.getPaddingLeft(), rv.getPaddingTop() + h, rv.getPaddingRight(), rv.getPaddingBottom());
        rv.setClipToPadding(false);
        parent.addView(e, new ViewGroup.LayoutParams(-1, h));
        rv.getViewTreeObserver().addOnPreDrawListener(() -> {
            try { sync(rv, e, h); } catch (Throwable ignored) { }
            return true;
        });
    }

    static void sync(ViewGroup rv, View e, int h) {
        float base = rv.getTop();
        if (!posUnsupported) {
            try {
                for (int i = 0; i < rv.getChildCount(); i++) {
                    View c = rv.getChildAt(i);
                    Object pos = XposedHelpers.callMethod(rv, "getChildAdapterPosition", c);
                    if (pos instanceof Integer && (Integer) pos == 0) {
                        e.setVisibility(View.VISIBLE);
                        e.setTranslationY(base + c.getTop() - h);
                        return;
                    }
                }
                e.setVisibility(View.INVISIBLE);
                return;
            } catch (Throwable t) { posUnsupported = true; }
        }
        // 兜底：取不到位置时，只在列表顶部显示
        e.setVisibility(rv.canScrollVertically(-1) ? View.INVISIBLE : View.VISIBLE);
        e.setTranslationY(base);
    }

    static boolean isRecycler(View v) {
        for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass())
            if (c.getName().contains("RecyclerView")) return true;
        return false;
    }

    static View findText(View v, String t) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) return v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findText(g.getChildAt(i), t);
                if (r != null) return r;
            }
        }
        return null;
    }

    // 两个文字的最近公共父容器 = 整个设置列表
    static ViewGroup lca(View a, View b) {
        Set<ViewParent> s = new HashSet<>();
        for (ViewParent p = a.getParent(); p != null; p = p.getParent()) s.add(p);
        for (ViewParent p = b.getParent(); p != null; p = p.getParent())
            if (p instanceof ViewGroup && s.contains(p)) return (ViewGroup) p;
        return null;
    }

    // ---------- 入口卡片（仿设置页的圆角白卡片） ----------

    static View buildEntry(final Activity a) {
        boolean night = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        FrameLayout wrap = new FrameLayout(a);
        wrap.setTag(TAG);
        wrap.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(night ? Color.parseColor("#252525") : Color.WHITE);
        bg.setCornerRadius(dp(a, 12));
        card.setBackground(bg);

        TextView t = new TextView(a);
        t.setText("抖音美化");
        t.setTextSize(16);
        t.setTextColor(night ? Color.parseColor("#E8E8E8") : Color.parseColor("#161823"));
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        wrap.addView(card, new FrameLayout.LayoutParams(-1, -1));
        wrap.setOnClickListener(v -> showMain(a));
        return wrap;
    }

    // ---------- 功能列表页（全屏页面，仿设置页风格） ----------

    static boolean isNight(Activity a) {
        return (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static TextView tv(Activity a, String s, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static Dialog page(final Activity a, String title, View... sections) {
        boolean n = isNight(a);
        final Dialog d = new Dialog(a, n ? android.R.style.Theme_Material_NoActionBar
                : android.R.style.Theme_Material_Light_NoActionBar);
        int bg = n ? 0xFF121212 : 0xFFF4F4F4;
        int fg = n ? 0xFFE8E8E8 : 0xFF161823;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        FrameLayout bar = new FrameLayout(a);
        TextView tt = tv(a, title, 17, fg);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        bar.addView(tt, new FrameLayout.LayoutParams(-1, -1));
        TextView back = tv(a, "‹", 30, fg);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> d.dismiss());
        bar.addView(back, new FrameLayout.LayoutParams(dp(a, 56), -1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(a, 52)));

        ScrollView sv = new ScrollView(a);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 24));
        for (View v : sections) list.addView(v);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(-1, -1);
            w.setStatusBarColor(bg);
            w.setNavigationBarColor(bg);
            w.getDecorView().setSystemUiVisibility(n ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        d.show();
        return d;
    }

    static LinearLayout card(Activity a) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(isNight(a) ? 0xFF252525 : 0xFFFFFFFF);
        g.setCornerRadius(dp(a, 12));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(a, 12);
        c.setLayoutParams(lp);
        return c;
    }

    static void addRow(Activity a, LinearLayout card, String text, View trailing, final Runnable click) {
        boolean n = isNight(a);
        if (card.getChildCount() > 0) {
            View dv = new View(a);
            dv.setBackgroundColor(n ? 0x22FFFFFF : 0x14000000);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.leftMargin = dp(a, 16);
            card.addView(dv, dl);
        }
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(a, 16), 0, dp(a, 16), 0);
        r.addView(tv(a, text, 16, n ? 0xFFE8E8E8 : 0xFF161823), new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) r.addView(trailing);
        if (click != null) r.setOnClickListener(v -> click.run());
        card.addView(r, new LinearLayout.LayoutParams(-1, dp(a, 56)));
    }

    static View arrow(Activity a) { return tv(a, "›", 22, 0xFF9A9A9A); }

    static void showMain(final Activity a) {
        LinearLayout c = card(a);
        addRow(a, c, "美化功能", arrow(a), () -> showBeautify(a));
        LinearLayout c2 = card(a);
        addRow(a, c2, "复制诊断信息（底部导航结构）", null, () -> copyDiag(a));
        page(a, "抖音美化", c, c2);
    }

    static void showBeautify(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout c = card(a);
        final Switch sw = new Switch(a);
        sw.setChecked(sp.getBoolean("liquid_nav", false));
        sw.setOnCheckedChangeListener((b, on) -> {
            sp.edit().putBoolean("liquid_nav", on).apply();
            Toast.makeText(a, on ? "已开启，回到首页后生效" : "已关闭", Toast.LENGTH_SHORT).show();
        });
        addRow(a, c, "1. 底部导航：液态玻璃（测试版）", sw, () -> sw.toggle());
        addRow(a, c, "2. 隐藏指定文字的控件", arrow(a), () -> showHide(a));
        page(a, "美化功能", c);
    }

    static void showHide(final Activity a) {
        final SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), 0);

        final Switch sw = new Switch(a);
        sw.setText("启用");
        sw.setChecked(sp.getBoolean("enabled", true));
        box.addView(sw);

        TextView tip = new TextView(a);
        tip.setText("\n隐藏包含以下文字的控件（逗号分隔）：");
        box.addView(tip);

        final EditText et = new EditText(a);
        et.setText(sp.getString("hide_keywords", ""));
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(a)
                .setTitle("隐藏指定文字的控件")
                .setView(box)
                .setPositiveButton("保存", (d, w) -> {
                    sp.edit().putBoolean("enabled", sw.isChecked())
                            .putString("hide_keywords", et.getText().toString()).apply();
                    Toast.makeText(a, "已保存，重新进入页面后生效", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------- 底部导航：定位 + 诊断（液态玻璃的前置步骤） ----------

    static final String AGSL =
            "uniform shader content;\n"
            + "uniform float4 box;\n"
            + "uniform float radius;\n"
            + "uniform float amount;\n"
            + "uniform float depthPx;\n"
            + "float sdr(float2 p, float2 hb, float r) {\n"
            + "  float2 q = abs(p) - hb + float2(r);\n"
            + "  return length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;\n"
            + "}\n"
            + "half4 main(float2 fc) {\n"
            + "  float2 c = float2((box.x + box.z) * 0.5, (box.y + box.w) * 0.5);\n"
            + "  float2 hb = float2((box.z - box.x) * 0.5, (box.w - box.y) * 0.5);\n"
            + "  float2 p = fc - c;\n"
            + "  float inside = -sdr(p, hb, radius);\n"
            + "  float2 off = float2(0.0);\n"
            + "  if (inside > 0.0 && inside < depthPx) {\n"
            + "    float t = 1.0 - inside / depthPx;\n"
            + "    float2 g = float2(sdr(p + float2(1.0, 0.0), hb, radius) - sdr(p - float2(1.0, 0.0), hb, radius),\n"
            + "                      sdr(p + float2(0.0, 1.0), hb, radius) - sdr(p - float2(0.0, 1.0), hb, radius));\n"
            + "    float gl = length(g);\n"
            + "    if (gl > 0.0001) { g = g / gl; }\n"
            + "    off = -g * amount * t * t;\n"
            + "  }\n"
            + "  return content.eval(fc + off);\n"
            + "}\n";

    static void applyGlass(Activity a, View decor) {
        try {
            SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
            glassEnabled = sp.getBoolean("liquid_nav", false);
            if (glassEnabled) installGlass(a, decor); else removeGlass();
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    static void installGlass(Activity a, View decor) {
        if (Build.VERSION.SDK_INT < 31) {
            if (!navToasted) {
                navToasted = true;
                Toast.makeText(a, "液态玻璃需要 Android 12 及以上", Toast.LENGTH_LONG).show();
            }
            return;
        }
        glassActRef = new WeakReference<>(a);
        View oldDecor = glassDecorRef == null ? null : glassDecorRef.get();
        if (oldDecor != decor) {
            if (oldDecor != null && glassListener != null) {
                try { oldDecor.getViewTreeObserver().removeOnPreDrawListener(glassListener); }
                catch (Throwable ignored) { }
            }
            glassListener = () -> {
                if (skipNext) { skipNext = false; return true; }
                View h = glassHostRef == null ? null : glassHostRef.get();
                long now = SystemClock.uptimeMillis();
                if (now - lastCheck > 500) {   // 看门狗：底栏被重建/背景被改回去时重新套上玻璃
                    lastCheck = now;
                    Activity act = glassActRef == null ? null : glassActRef.get();
                    View dec = glassDecorRef == null ? null : glassDecorRef.get();
                    if (glassEnabled && act != null && dec != null) {
                        try { ensureGlass(act, dec); } catch (Throwable t) { XposedBridge.log(t); }
                        h = glassHostRef == null ? null : glassHostRef.get();
                    }
                }
                if (h != null && h.isAttachedToWindow()) { skipNext = true; h.invalidate(); }
                return true;
            };
            decor.getViewTreeObserver().addOnPreDrawListener(glassListener);
            glassDecorRef = new WeakReference<>(decor);
        }
        ensureGlass(a, decor);
    }

    static void ensureGlass(Activity a, View decor) {
        View host = glassHostRef == null ? null : glassHostRef.get();
        Glass g = glassRef == null ? null : glassRef.get();
        if (host != null && host.isAttachedToWindow() && g != null) {
            if (host.getBackground() != g) {
                ownSet = true;
                try { host.setBackground(g); } finally { ownSet = false; }
            }
            return;
        }
        ViewGroup nav = findNav(decor);
        if (nav == null) return;
        host = null;
        for (ViewParent p = nav.getParent(); p instanceof View; p = p.getParent()) {
            if (p.getClass().getName().contains("MainBottomTabContainer")) { host = (View) p; break; }
        }
        if (host == null) { XposedBridge.log("DyUI: MainBottomTabContainer not found"); return; }

        // nav → host 之间的 View：保存原背景、打标记（之后抖音再设背景会被拦截）、清掉背景
        ArrayList<View> chain = new ArrayList<>();
        for (View v = nav; ; v = (View) v.getParent()) { chain.add(v); if (v == host) break; }
        savedBgs = new ArrayList<>();
        int base = 0;
        boolean hasBase = false;
        ownSet = true;
        try {
            for (int i = chain.size() - 1; i >= 0; i--) {
                View v = chain.get(i);
                Drawable d = v.getBackground();
                savedBgs.add(new Object[]{new WeakReference<>(v), d});
                if (!hasBase && d instanceof ColorDrawable && Color.alpha(((ColorDrawable) d).getColor()) > 0) {
                    base = ((ColorDrawable) d).getColor();
                    hasBase = true;
                }
                v.setTag(KEY, Boolean.TRUE);
                if (d != null) v.setBackground(null);
            }
            Glass glass = new Glass(host, decor, a.getResources().getDisplayMetrics().density, hasBase ? base : 0);
            host.setBackground(glass);
            glassRef = new WeakReference<>(glass);
            glassHostRef = new WeakReference<>(host);
        } finally { ownSet = false; }
        if (!glassToasted) {
            glassToasted = true;
            Toast.makeText(a, "液态玻璃已启用", Toast.LENGTH_SHORT).show();
        }
    }

    static void removeGlass() {
        glassEnabled = false;
        View dec = glassDecorRef == null ? null : glassDecorRef.get();
        try {
            if (dec != null && glassListener != null) dec.getViewTreeObserver().removeOnPreDrawListener(glassListener);
        } catch (Throwable ignored) { }
        glassListener = null;
        glassDecorRef = null;
        ownSet = true;
        try {
            if (savedBgs != null) for (Object[] sv : savedBgs) {
                @SuppressWarnings("unchecked")
                View v = ((WeakReference<View>) sv[0]).get();
                if (v != null) {
                    v.setTag(KEY, null);
                    v.setBackground((Drawable) sv[1]);
                }
            }
        } catch (Throwable t) { XposedBridge.log(t); }
        finally { ownSet = false; }
        savedBgs = null;
        glassHostRef = null;
        glassRef = null;
    }

    // 把“排在 target 之前绘制的所有内容”画到 c 上，画完后 c 的原点就在 target 的左上角
    static void drawBelow(Canvas c, View root, View target) {
        ArrayList<View> path = new ArrayList<>();
        View v = target;
        while (v != null) {
            path.add(0, v);
            if (v == root) break;
            ViewParent p = v.getParent();
            v = (p instanceof View) ? (View) p : null;
        }
        if (path.isEmpty() || path.get(0) != root) return;
        for (int i = 0; i < path.size() - 1; i++) {
            ViewGroup g = (ViewGroup) path.get(i);
            View next = path.get(i + 1);
            Drawable bg = g.getBackground();
            if (bg != null) bg.draw(c);
            for (int j = 0; j < g.getChildCount(); j++) {
                View ch = g.getChildAt(j);
                if (ch == next) break;
                if (ch.getVisibility() != View.VISIBLE || ch.getAlpha() <= 0f) continue;
                c.save();
                c.translate(ch.getLeft() - g.getScrollX(), ch.getTop() - g.getScrollY());
                ch.draw(c);
                c.restore();
            }
            c.translate(next.getLeft() - g.getScrollX(), next.getTop() - g.getScrollY());
        }
    }

    // 液态玻璃背景：取底栏后面的内容 → 模糊 → 边缘折射(AGSL) → 着色 → 边缘高光
    static class Glass extends Drawable {
        final View target, root;
        final float dens;
        int tintColor;
        final Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path = new Path();
        final RectF rect = new RectF();
        RenderNode node;
        boolean fx;
        int lastW, lastH;

        Glass(View target, View root, float dens, int baseColor) {
            this.target = target;
            this.root = root;
            this.dens = dens;
            setBase(baseColor);
            try { node = new RenderNode("dyui_glass"); fx = true; } catch (Throwable t) { fx = false; }
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(1.5f * dens);
        }

        // 底色跟着抖音的底栏主题走（首页深色、其他页浅色），保证文字对比度
        void setBase(int color) {
            tintColor = Color.alpha(color) > 0 ? ((color & 0x00FFFFFF) | (0x99 << 24)) : 0x33FFFFFF;
            invalidateSelf();
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            int w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) return;
            rect.set(b.left + 16 * dens, b.top + 8 * dens, b.right - 16 * dens, b.bottom - 8 * dens);
            float r = rect.height() / 2f;
            path.reset();
            path.addRoundRect(rect, r, r, Path.Direction.CW);

            if (fx && c.isHardwareAccelerated()) {
                try {
                    if (w != lastW || h != lastH) { build(r); lastW = w; lastH = h; }
                    node.setPosition(0, 0, w, h);
                    node.setClipToBounds(true);
                    Canvas rc = node.beginRecording(w, h);
                    try { drawBelow(rc, root, target); } finally { node.endRecording(); }
                    c.save();
                    c.clipPath(path);
                    c.drawRenderNode(node);
                    c.restore();
                } catch (Throwable t) {
                    fx = false;
                    XposedBridge.log(t);
                }
            }
            tint.setColor(tintColor);
            c.drawRoundRect(rect, r, r, tint);
            c.drawRoundRect(rect, r, r, rim);
        }

        void build(float r) {
            RenderEffect e = RenderEffect.createBlurEffect(8 * dens, 8 * dens, Shader.TileMode.CLAMP);
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    RuntimeShader s = new RuntimeShader(AGSL);
                    s.setFloatUniform("box", rect.left, rect.top, rect.right, rect.bottom);
                    s.setFloatUniform("radius", r);
                    s.setFloatUniform("amount", 14 * dens);
                    s.setFloatUniform("depthPx", rect.height() * 0.45f);
                    e = RenderEffect.createChainEffect(RenderEffect.createRuntimeShaderEffect(s, "content"), e);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
            node.setRenderEffect(e);
            rim.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    new int[]{0xCCFFFFFF, 0x14FFFFFF, 0xCCFFFFFF}, null, Shader.TileMode.CLAMP));
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    // 底部导航 = “首页”和“我”两个文字的公共父容器（要求位于屏幕下方）
    static ViewGroup findNav(View decor) {
        int h = decor.getResources().getDisplayMetrics().heightPixels;
        View home = findTextBottom(decor, "首页", h), me = findTextBottom(decor, "我", h);
        if (home == null || me == null) return null;
        return lca(home, me);
    }

    static View findTextBottom(View v, String t, int screenH) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && t.equals(s.toString().trim())) {
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);
                if (loc[1] > screenH * 0.75f) return v;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findTextBottom(g.getChildAt(i), t, screenH);
                if (r != null) return r;
            }
        }
        return null;
    }

    static void dumpView(StringBuilder sb, View v, int depth, int max) {
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName()).append(' ').append(v.getWidth()).append('x').append(v.getHeight());
        if (v instanceof TextView) sb.append(" \"").append(((TextView) v).getText()).append('"');
        if (v.getId() > 0) {
            try { sb.append(" id=").append(v.getResources().getResourceEntryName(v.getId())); }
            catch (Throwable ignored) { }
        }
        sb.append('\n');
        if (depth < max && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpView(sb, g.getChildAt(i), depth + 1, max);
        }
    }

    static void copyDiag(Activity a) {
        Activity m = mainRef == null ? null : mainRef.get();
        if (m == null) {
            Toast.makeText(a, "请先回到抖音首页，再进来点一次", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder("DyUI diag\n");
        try {
            sb.append("douyin=").append(m.getPackageManager().getPackageInfo(HOST, 0).versionName).append('\n');
        } catch (Throwable ignored) { }
        sb.append("activity=").append(m.getClass().getName()).append('\n');
        ViewGroup nav = findNav(m.getWindow().getDecorView());
        if (nav == null) {
            sb.append("nav=not found\n");
        } else {
            sb.append("nav parents:\n");
            int k = 0;
            for (ViewParent p = nav.getParent(); p instanceof View && k < 5; p = p.getParent(), k++) {
                View pv = (View) p;
                sb.append("  ").append(pv.getClass().getName()).append(' ')
                        .append(pv.getWidth()).append('x').append(pv.getHeight()).append('\n');
            }
            sb.append("nav tree:\n");
            dumpView(sb, nav, 0, 4);
        }
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("dyui", sb.toString()));
        Toast.makeText(a, "已复制，粘贴发给我即可", Toast.LENGTH_LONG).show();
    }

    // ---------- 美化功能（示例：按文字隐藏控件，更多功能加在这里） ----------

    static void applyBeautify(Activity a, View root) {
        SharedPreferences sp = a.getSharedPreferences("dyui", Context.MODE_PRIVATE);
        if (!sp.getBoolean("enabled", true)) return;
        String kw = sp.getString("hide_keywords", "").trim();
        if (kw.isEmpty()) return;
        walk(root, kw.split("[,，]"));
    }

    static void walk(View v, String[] kws) {
        if (TAG.equals(v.getTag())) return;
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null) for (String k : kws) {
                if (!k.trim().isEmpty() && s.toString().contains(k.trim())) {
                    v.setVisibility(View.GONE);
                    break;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), kws);
        }
    }

    static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
